package com.gdylet.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

private val Bg = Color(0xFF080D18)
private val Panel = Color(0xFF111A2B)
private val Blue = Color(0xFF4D8DFF)
private val TextMain = Color(0xFFF2F5FC)
private val TextMuted = Color(0xFF9EACC4)
private const val PREFS = "gdylet_prefs"
private const val KEY_HISTORY = "history"
private const val KEY_SERVER = "server_url"

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ru", "RU")
        }
        setContent { GdyletApp(
            readPrefs = { getSharedPreferences(PREFS, MODE_PRIVATE) },
            speak = { text -> tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "gdylet_reply") }
        ) }
    }
    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

private fun assistantRule(text: String): String? {
    val lower = text.lowercase()
    return if (listOf("кто тебя создал", "кто создал тебя", "твой создатель", "кто твой создатель").any { lower.contains(it) }) {
        "Меня создал простой парень из села Гдулет, Республики Южная Осетия."
    } else null
}

private suspend fun requestAssistant(
    baseUrl: String,
    messages: List<ChatMessage>,
    search: Boolean
): String = withContext(Dispatchers.IO) {
    val cleanBase = baseUrl.trim().trimEnd('/')
    require(cleanBase.startsWith("https://")) { "Укажи HTTPS-адрес своего сервера в настройках." }
    val url = URL("$cleanBase/api/chat")
    val connection = (url.openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 90000
        doOutput = true
        setRequestProperty("Content-Type", "application/json; charset=utf-8")
    }
    try {
        val body = JSONObject()
        val array = JSONArray()
        messages.takeLast(16).forEach { m ->
            array.put(JSONObject().put("role", if (m.fromUser) "user" else "assistant").put("content", m.text))
        }
        body.put("messages", array)
        body.put("search", search)
        connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val responseText = stream.bufferedReader().use { it.readText() }
        val json = JSONObject(responseText)
        if (code !in 200..299) throw IllegalStateException(json.optString("error", "Ошибка сервера ($code)"))
        json.optString("reply").ifBlank { "Сервер вернул пустой ответ." }
    } finally {
        connection.disconnect()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GdyletApp(
    readPrefs: () -> android.content.SharedPreferences,
    speak: (String) -> Unit
) {
    val prefs = remember { readPrefs() }
    var input by remember { mutableStateOf("") }
    var serverUrl by remember { mutableStateOf(prefs.getString(KEY_SERVER, "") ?: "") }
    var showSettings by remember { mutableStateOf(false) }
    var searchEnabled by remember { mutableStateOf(true) }
    var loading by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Укажи адрес сервера в настройках для подключения ИИ") }
    val scope = rememberCoroutineScope()
    val messages = remember {
        mutableStateListOf<ChatMessage>().apply {
            val saved = prefs.getString(KEY_HISTORY, null)
            if (!saved.isNullOrBlank()) {
                try {
                    val arr = JSONArray(saved)
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(ChatMessage(o.getString("text"), o.getBoolean("user")))
                    }
                } catch (_: Exception) { clear() }
            }
            if (isEmpty()) add(ChatMessage("Привет! Я Gdylet. Настрой сервер, и мы подключим настоящий ИИ.", false))
        }
    }

    fun saveHistory() {
        val arr = JSONArray()
        messages.takeLast(60).forEach { m ->
            arr.put(JSONObject().put("text", m.text).put("user", m.fromUser))
        }
        prefs.edit().putString(KEY_HISTORY, arr.toString()).apply()
    }

    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) input = spoken
    }

    fun sendMessage() {
        val text = input.trim()
        if (text.isEmpty() || loading) return
        input = ""
        messages.add(ChatMessage(text, true))
        saveHistory()
        val special = assistantRule(text)
        if (special != null) {
            messages.add(ChatMessage(special, false))
            saveHistory()
            return
        }
        if (serverUrl.isBlank()) {
            messages.add(ChatMessage("Чтобы я отвечал с помощью настоящего ИИ, открой настройки и укажи HTTPS-адрес сервера Gdylet. Сервер и API пока не подключены.", false))
            saveHistory()
            return
        }
        loading = true
        status = if (searchEnabled) "Gdylet думает и при необходимости ищет в интернете…" else "Gdylet думает…"
        scope.launch {
            try {
                val reply = requestAssistant(serverUrl, messages.toList(), searchEnabled)
                messages.add(ChatMessage(reply, false))
                status = "Онлайн-запрос выполнен"
                saveHistory()
            } catch (e: Exception) {
                val reason = e.message ?: "неизвестная ошибка"
                messages.add(ChatMessage("Не удалось связаться с ИИ: $reason", false))
                status = "Нет соединения с сервером"
                saveHistory()
            } finally {
                loading = false
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Blue, background = Bg, surface = Panel, onBackground = TextMain, onSurface = TextMain)) {
        Scaffold(
            containerColor = Bg,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Gdylet", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = TextMain)
                            Text(if (serverUrl.isBlank()) "Настройка подключения" else "Персональный ИИ-помощник", color = TextMuted, fontSize = 12.sp)
                        }
                    },
                    actions = {
                        IconButton(onClick = { showSettings = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Настройки", tint = Blue)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Bg)
                )
            },
            bottomBar = {
                Column(Modifier.fillMaxWidth().background(Bg).padding(horizontal = 12.dp, vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            placeholder = { Text("Напиши Gdylet…", color = TextMuted) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(24.dp),
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Blue, unfocusedBorderColor = Color(0xFF26344C),
                                focusedTextColor = TextMain, unfocusedTextColor = TextMain, cursorColor = Blue
                            )
                        )
                        IconButton(
                            onClick = {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Говорите с Gdylet")
                                }
                                try { voiceLauncher.launch(intent) } catch (_: Exception) { status = "Голосовой ввод недоступен на этом устройстве" }
                            },
                            modifier = Modifier.background(Panel, CircleShape)
                        ) { Icon(Icons.Default.GraphicEq, contentDescription = "Голосовой ввод", tint = Blue) }
                        IconButton(onClick = { sendMessage() }, modifier = Modifier.background(Blue, CircleShape)) {
                            Icon(Icons.Default.Send, contentDescription = "Отправить", tint = Color.White)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = searchEnabled, onCheckedChange = { searchEnabled = it }, colors = CheckboxDefaults.colors(checkedColor = Blue))
                        Text("Разрешить интернет-поиск", color = TextMuted, fontSize = 12.sp)
                        Spacer(Modifier.weight(1f))
                        if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Blue)
                    }
                    Text(status, color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp, top = 2.dp))
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 14.dp),
                contentPadding = PaddingValues(vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(68.dp).background(
                            androidx.compose.ui.graphics.Brush.linearGradient(listOf(Blue, Color(0xFF8A5CFF))), CircleShape
                        ), contentAlignment = Alignment.Center) {
                            Text("G", color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Чем могу помочь?", color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 20.sp)
                    }
                }
                items(messages) { message ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
                        Surface(
                            color = if (message.fromUser) Color(0xFF1C3D70) else Panel,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.widthIn(max = 320.dp)
                        ) {
                            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                                Text(message.text, color = TextMain, fontSize = 15.sp, lineHeight = 21.sp)
                                if (!message.fromUser) {
                                    TextButton(
                                        onClick = { speak(message.text) },
                                        contentPadding = PaddingValues(0.dp),
                                        modifier = Modifier.height(28.dp)
                                    ) {
                                        Icon(Icons.Default.VolumeUp, contentDescription = "Озвучить", tint = Blue, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Озвучить", color = Blue, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("Подключение Gdylet") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Введи HTTPS-адрес опубликованного серверного API. Не вставляй сюда API-ключ OpenAI.", color = TextMuted)
                        OutlinedTextField(
                            value = serverUrl,
                            onValueChange = { serverUrl = it },
                            label = { Text("Адрес сервера") },
                            placeholder = { Text("https://your-server.example.com") },
                            singleLine = true
                        )
                        Text("Серверная часть находится в папке backend архива. Пока сервер не размещён, онлайн-ответы не заработают.", color = TextMuted, fontSize = 12.sp)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        serverUrl = serverUrl.trim().trimEnd('/')
                        prefs.edit().putString(KEY_SERVER, serverUrl).apply()
                        showSettings = false
                        status = if (serverUrl.isBlank()) "Адрес сервера не задан" else "Адрес сохранён; проверь подключение"
                    }) { Text("Сохранить") }
                },
                dismissButton = { TextButton(onClick = { showSettings = false }) { Text("Отмена") } },
                containerColor = Panel,
                titleContentColor = TextMain,
                textContentColor = TextMuted
            )
        }
    }
}
