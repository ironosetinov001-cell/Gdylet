import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(express.json({ limit: "64kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 30, standardHeaders: "draft-7", legacyHeaders: false }));

const apiKey = process.env.OPENAI_API_KEY;
const model = process.env.OPENAI_MODEL || "gpt-5.5";
const port = Number(process.env.PORT || 3000);
const client = apiKey ? new OpenAI({ apiKey }) : null;

const systemInstructions = `
Ты — Gdylet, дружелюбный и честный персональный ИИ-помощник. Отвечай на языке пользователя.
Если тебя спрашивают, кто тебя создал, отвечай ровно: «Меня создал простой парень из села Гдулет, Республики Южная Осетия».
Не выдумывай факты и источники. Если использовал веб-поиск, сохраняй ссылки и цитаты, которые вернул сервис.
Не проси пользователя отправлять пароли, API-ключи или секретные данные.
`;

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "gdylet-backend", configured: Boolean(client), model });
});

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) {
      return res.status(503).json({ error: "Сервер не настроен: добавьте OPENAI_API_KEY в переменные окружения." });
    }

    const rawMessages = req.body?.messages;
    if (!Array.isArray(rawMessages) || rawMessages.length === 0 || rawMessages.length > 16) {
      return res.status(400).json({ error: "Передайте от 1 до 16 сообщений." });
    }

    const input = rawMessages.map((m) => {
      const role = m?.role === "assistant" ? "assistant" : "user";
      const content = String(m?.content ?? "").slice(0, 8000);
      return { role, content };
    });

    const useSearch = req.body?.search === true;
    const response = await client.responses.create({
      model,
      instructions: systemInstructions,
      input,
      ...(useSearch ? { tools: [{ type: "web_search" }] } : {})
    });

    res.json({ reply: response.output_text || "Не удалось получить текстовый ответ." });
  } catch (error) {
    console.error("Gdylet API error:", error?.status || "", error?.message || "unknown");
    const status = Number(error?.status) >= 400 && Number(error?.status) < 600 ? Number(error.status) : 502;
    res.status(status).json({
      error: status === 401 ? "Ошибка авторизации API. Проверьте ключ на сервере." :
             status === 429 ? "Превышен лимит API. Попробуйте позже." :
             "Сервер ИИ временно не смог обработать запрос."
    });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Gdylet backend listening on ${port}; model=${model}; API key configured=${Boolean(client)}`);
});
